<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title> <?php echo $pagetitle; ?> - RLHAPT Dashboard</title>        
        <link rel="shortcut icon" href="favicon.ico" />
        <!-- Bootstrap -->
        <link href="includes/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="includes/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="includes/vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="includes/assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="includes/vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                  
	                    <a class="brand" href="dashboard.php"><img src="images/rlhapt.png" />RLHAPT</a>
                    
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo $name; ?> <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <!--a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li-->
                                        <a tabindex="-1" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                           <?php 
                    				if($pagetitle == 'Overview')
                        			echo '<li class="active">';
                        		else
											echo '<li>';
                    			?>
                                <a href="dashboard.php">Overview</a>
                            </li>
                           <?php 
                    				if($pagetitle == 'Machines')
                        			echo '<li class="active">';
                        		else
											echo '<li>';
                    			?>
                                <a href="machines.php">Machines</a>
                            </li>
                           <?php 
                    				if($pagetitle == 'Networks')
                        			echo '<li class="active">';
                        		else
											echo '<li>';
                    			?>
                                <a href="network.php">Networks</a>
                            </li>
                           <?php 
                    				if($pagetitle == 'Instances')
                        			echo '<li class="active">';
                        		else
											echo '<li>';
                    			?>
                                <a href="instance.php">Instances</a>
                            </li>                            
                            <?php 
                    				if($pagetitle == 'Submit Flag')
                        			echo '<li class="active">';
                        		else
											echo '<li>';
                    			?>
                    			   <a href="submitflag.php">Submit Flag</a>
                            </li>
                            <?php 
                    				if($pagetitle == 'Monitoring')
                        			echo '<li class="active">';
                        		else
											echo '<li>';
                    			?>
                    			   <a href="monitoring.php">Monitoring</a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                    <?php 
                    		if($pagetitle == 'Overview')
                        	echo '<li class="active">';
                        else
									echo '<li>';
                    ?>
                            <a href="dashboard.php"><i class="icon-chevron-right"></i> Overview</a>
                        </li>
                     <?php 
                    		if($pagetitle == 'Machines')
                        	echo '<li class="active">';
                        else
									echo '<li>';
                    ?>
                            <a href="machines.php"><i class="icon-chevron-right"></i> Machines</a>
                        </li>
                    <?php 
                    		if($pagetitle == 'Networks')
                        	echo '<li class="active">';
                        else
									echo '<li>';
                    ?>
                            <a href="network.php"><i class="icon-chevron-right"></i> Networks</a>
                        </li>
                    <?php 
                    		if($pagetitle == 'Instances')
                        	echo '<li class="active">';
                        else
									echo '<li>';
                    ?>
                            <a href="instance.php"><i class="icon-chevron-right"></i> Instances</a>
                        </li>
                    <?php 
                    		if($pagetitle == 'Submit Flag')
                        	echo '<li class="active">';
                        else
									echo '<li>';
                    ?>
                            <a href="submitflag.php"><i class="icon-chevron-right"></i> Submit Flag</a>
                        </li>
                    <?php 
                    		if($pagetitle == 'Monitoring')
                        	echo '<li class="active">';
                        else
									echo '<li>';
                    ?>
                            <a href="monitoring.php"><i class="icon-chevron-right"></i> Monitoring</a>
                        </li>
                        <li>
                            <a href="logout.php"> Logout</a>
                        </li>
                    </ul>
                </div>