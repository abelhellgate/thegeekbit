<?php

include 'session.php';
$pagetitle = 'Submit Flag';
	
if( isset($_POST['flag']) ){

		$flag = $_POST['flag'];
		
		
}

include 'header.php';

?>
					<div class="span9" id="content">
                
                <!--Success Message Code -->
                <?php	
                
                	if(isset($_GET['status'])){
                	
                			$status = $_GET['status'];
                			if($status == 'success'){
                			
                	
                ?>
                	<div class="row-fluid">
                        <!-- block -->
                        <!--div class="block"-->
                        
                            <div class="block-content collapse in">
                            	<div class="span12">
                           	<div class="alert alert-success alert-block">
												<a class="close" data-dismiss="alert" href="#">&times;</a>
												<h4 class="alert-heading">Success!</h4>
												The Flag Submitted and Verified Successfully!
										</div>

										</div>
                            </div>
                        </div>
                        <!-- /block -->
                <?php
                
								}
                	}
                                
                ?>
                <!--Success Message Code Ends -->
                
                    <!-- Form Validation -->
                   <div class="row-fluid">
                         <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Submit Flag</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
					<!-- BEGIN FORM-->
					<form action="submitflag.php" id="flag-form" class="form-horizontal" method="POST">
						<fieldset>
							
  							<div class="control-group">
  								<label class="control-label">Flag<span class="required">*</span></label>
  								<div class="controls">
  									<input name="flag" type="text" class="span6 m-wrap"/>
  								</div>
  							</div>
  							
  							
  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Submit Flag</button>
  							</div>
						</fieldset>
					</form>
					<!-- END FORM-->
				</div>
			    </div>
			</div>
                     	<!-- /block -->
		    </div>
                    
                </div>
            </div>
            <?php include 'footer.php'; ?>