<?php

$connection = mysqli_connect("localhost", "root", "killmenow", "rlhapt") or die("Couldn't Establish Connection To Database!");