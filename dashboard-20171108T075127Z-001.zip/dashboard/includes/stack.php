<?php

	require '/var/www/html/dashboard/includes/cloud/autoload.php';

	$authurl = 'http://192.168.3.101/identity/v3';
	$region = 'RegionOne';
	$id = 'd45c91abcd26447091b367a0fdeddf5b';
	$pass = 'freedom';
	$projectId = '0a1163c0a5b448a3aac6ba57207faabd';

	$cloud = new OpenStack\OpenStack([
    	'authUrl' => $authurl,
    	'region'  => $region,
    	'user'    => [
        	'id'       => $id,
        	'password' => $pass
    	],
    	'scope'   => ['project' => ['id' => $projectId]]

	]);   