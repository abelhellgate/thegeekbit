<?php

function total_users($connection){

	$query = "SELECT COUNT(user_id) FROM User WHERE user_role = 'User'";
	$result = mysqli_query($connection, $query);
   $rows = mysqli_fetch_row($result);
   
   return $rows[0];
}

function total_machines($cloud, $region){

	$compute = $cloud->computeV2(['region' => $region]);
	$servers = $compute->listServers(true);
	$i = 0;
	foreach ($servers as $server) {
		$i++;
	}
	
	return $i;
}

function total_networks($cloud){

	$networking = $cloud->networkingV2();
	$networks = $networking->listNetworks();
	$i = 0;

	foreach($networks as $network){
		$i++;
	}
	
	return $i;
}

function get_userName($connection, $user_id){
	
	$query = "SELECT first_name, last_name FROM User WHERE user_id = '$user_id'";
	$result = mysqli_query($connection, $query);
   $rows = mysqli_fetch_array($result);
   
   $name = $rows['first_name'].' '.$rows['last_name'];
   
   return $name;

}

function get_user_percent($connection){

	$num = total_users($connection); 
	$percent = ($num / 100) * 500;

	return $percent;
}

function get_server_memory_usage(){

    $free = shell_exec('free');
    $free = (string)trim($free);
    $free_arr = explode("\n", $free);
    $mem = explode(" ", $free_arr[1]);
    $mem = array_filter($mem);
    $mem = array_merge($mem);
    $memory_usage = $mem[2]/$mem[1]*100;

    return round($memory_usage);
}

function get_server_cpu_usage(){

    $load = sys_getloadavg();
    return round($load[0]+23);

}

function createNetwork($cloud, $networkName){

    $networking = $cloud->networkingV2();

    $options = [
        'name'         => "$networkName",
        'adminStateUp' => true,
    ];

    // Create the network
    $network = $networking->createNetwork($options);
    $extractData = get_object_vars($network);
    
    return $extractData['id'];
}

function createSubnet($cloud, $networkid, $subnetName, $ip, $cidr){

	$networking = $cloud->networkingV2();

	$options = [
    	'name'      => $subnetName,
    	'networkId' => $networkid,
    	'ipVersion' => 4,
    	'cidr'      => $ip.'/'.$cidr
	];

	// Create the subnet
	try {
		$subnet = $networking->createSubnet($options);
		
	}catch (BadResponseException $e) {

    	echo $e->getResponse();
	}
	
	$extractData = get_object_vars($subnet);
	
	$subnetid = $extractData['id'];
	
	$networking = $cloud->networkingV2ExtLayer3();

	$router = $networking->getRouter('3a94dab9-0049-4dba-bc28-7a044088eaff');

	try {
		$router->addInterface(['subnetId' => $subnetid]);
	}catch (BadResponseException $e) {

    	echo $e->getResponse();
	}
	
	return $subnetid;
}

function createInstance($cloud, $instanceName, $region, $imageid, $networkid){

	$compute = $cloud->computeV2(['region' => $region]);
	
	$options = [	
   	'name' => $instanceName,
   	'imageId' => $imageid,
   	'flavorId' => 'd2',
		'networks' => [ ['uuid' => $networkid] ]
	];

	try {
		$server = $compute->createServer($options);
		$extractData = get_object_vars($server);
		$serverid = $extractData['id'];
				
		sleep(20);
	
		$server2 = $compute->getServer(['id' => $serverid]);
		$server2->retrieve();
		$extractData = get_object_vars($server2);
		
		foreach($extractData['addresses'] as $a){
			$private_ip = $a[0]['addr'];
		}
		
		$networking = $cloud->networkingV2();
		$portid = '';
		
		foreach ($networking->listPorts() as $port) {
			$extractData = get_object_vars($port);
			$ip = $extractData['fixedIps'][0]['ip_address'];
			
			if($ip == $private_ip){
					$portid = $extractData['id'];	
			}
		}
						
	}catch (BadResponseException $e) {
		
    	echo $e->getResponse();
	}
	
	try{
		$networking = $cloud->networkingV2ExtLayer3();

		$ip = $networking->createFloatingIp([
    		"floatingNetworkId" => "0d89a5f8-9712-4801-b492-f10be1c14fa2",
    		"portId"            => $portid,
    		"fixedIpAddress"    => $private_ip
		]);
		
	}catch (BadResponseException $e) {
		
    	echo $e->getResponse();
	}
	
	return $serverid;

}

function startServer($cloud, $region, $machine_id){

	$compute = $cloud->computeV2(['region' => $region]);
	$server = $compute->getServer(['id' => $machine_id]);

	$statusid = $server->start();

	return $statusid;

}

function stopServer($cloud, $region, $machine_id){

	$compute = $cloud->computeV2(['region' => $region]);
	$server = $compute->getServer(['id' => $machine_id]);

	$statusid = $server->stop();

	return $statusid;
	
}

function rebootServer($cloud, $region, $machine_id){

	$compute = $cloud->computeV2(['region' => $region]);
	$server = $compute->getServer(['id' => $machine_id]);

	$statusid = $server->reboot();

	return $statusid;

}

?>