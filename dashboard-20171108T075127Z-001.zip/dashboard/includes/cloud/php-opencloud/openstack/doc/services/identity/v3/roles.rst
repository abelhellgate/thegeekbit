Roles
=====

Add role
--------

.. sample:: identity/v3/roles/add_role.php
.. refdoc:: OpenStack/Identity/v3/Models/Project.html#method_createRole

List roles
----------

.. sample:: identity/v3/roles/list_roles.php
.. refdoc:: OpenStack/Identity/v3/Models/Project.html#method_listRoles

List role assignments
---------------------

.. sample:: identity/v3/roles/list_assignments.php
.. refdoc:: OpenStack/Identity/v3/Models/Project.html#method_listRoleAssignments
