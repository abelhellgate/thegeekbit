<?php

namespace OpenStack\Test\Common\Service\Fixtures\Identity;

use OpenStack\Common\Api\AbstractApi;

class Api extends AbstractApi
{
}
