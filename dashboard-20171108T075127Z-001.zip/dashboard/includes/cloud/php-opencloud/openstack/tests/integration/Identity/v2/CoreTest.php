<?php

namespace OpenStack\integration\Identity\v2;

use OpenStack\Integration\TestCase;

class CoreTest extends TestCase
{
    public function runTests()
    {
    }
}
