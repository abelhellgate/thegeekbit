<?php

include 'session.php';
$pagetitle = 'Networks';
	
if(isset($_POST['networkname']) && isset($_POST['ipaddr']) && isset($_POST['subnetname']) && isset($_POST['cidrmask'])){

		$networkname = $_POST['networkname'];
		$subnetname = $_POST['subnetname'];
		$ipaddress = $_POST['ipaddr'];
		$cidrnetmask = $_POST['cidrmask'];
		$subnetid = 0;
		
		$networkid = createNetwork($cloud, $networkname);		
		$subnetid = createSubnet($cloud, $networkid, $subnetname, $ipaddress, $cidrnetmask);
		
		if($subnetid != 0){
			
			header('Location: network.php?status=success');
		}
}

include 'header.php';

?>
					<div class="span9" id="content">
                
                <!--Success Message Code -->
                <?php	
                
                	if(isset($_GET['status'])){
                	
                			$status = $_GET['status'];
                			if($status == 'success'){
                			
                	
                ?>
                	<div class="row-fluid">
                        <!-- block -->
                        <!--div class="block"-->
                        
                            <div class="block-content collapse in">
                            	<div class="span12">
                           	<div class="alert alert-success alert-block">
												<a class="close" data-dismiss="alert" href="#">&times;</a>
												<h4 class="alert-heading">Success!</h4>
												The Network and the Subnet has successfully been created.
										</div>

										</div>
                            </div>
                        </div>
                        <!-- /block -->
                <?php
                
								}
                	}
                                
                ?>
                <!--Success Message Code Ends -->
                
                    <!-- Form Validation -->
                   <div class="row-fluid">
                         <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Create Network</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
					<!-- BEGIN FORM-->
					<form action="network.php" id="network-form" class="form-horizontal" method="POST">
						<fieldset>
							
  							<div class="control-group">
  								<label class="control-label">Network Name<span class="required">*</span></label>
  								<div class="controls">
  									<input name="networkname" type="text" class="span6 m-wrap"/>
  								</div>
  							</div>
  							
  							<div class="control-group">
  								<label class="control-label">Subnet Name<span class="required">*</span></label>
  								<div class="controls">
  									<input name="subnetname" type="text" class="span6 m-wrap"/>
  								</div>
  							</div>
  							
  							<div class="control-group">
  								<label class="control-label">IP Address<span class="required">*</span></label>
  								<div class="controls">
  									<input name="ipaddr" type="text" class="span6 m-wrap"/>
  								</div>
  							</div>
  							
  							<div class="control-group">
  								<label class="control-label">CIDR Subnet Mask<span class="required">*</span></label>
  								<div class="controls">
  									<input name="cidrmask" type="text" class="span6 m-wrap"/>
  								</div>
  							</div>
  							
  							
  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Create Network</button>
  							</div>
						</fieldset>
					</form>
					<!-- END FORM-->
				</div>
			    </div>
			</div>
                     	<!-- /block -->
		    </div>
                    
                </div>
            </div>
            <?php include 'footer.php'; ?>