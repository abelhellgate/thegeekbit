				<hr>
				<footer>
                <center><p>&copy; 2017 - RLHAPT </p></center>
            </footer>
        </div>

        <!--/.fluid-container-->
        <script src="includes/vendors/jquery-1.9.1.min.js"></script>
        <script src="includes/bootstrap/js/bootstrap.min.js"></script>
        <script src="includes/vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="includes/assets/scripts.js"></script>

        <script>
        $(function() {
            // Easy pie charts
            $('.chart').easyPieChart({animate: 1000});
        });
        </script>

    </body>

</html>