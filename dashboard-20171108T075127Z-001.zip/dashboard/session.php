<?php

	ob_start();
	session_start();

	if($_SESSION['loggedin'] != 'true'){

		header('Location: login.php?err=1');
	
	}

	include 'includes/connection.php';
	include 'includes/stack.php';
	include 'includes/functions.php';

	$name = get_userName($connection, $_SESSION['user_id']);

?>