<?php

	ob_start();
	session_start();
	
	if(isset($_SESSION['loggedin'])){

		header('Location: dashboard.php');
	
	}

?>

<!DOCTYPE html>
<html>

<head>
	<title> RLHAPT </title>
	<link rel="shortcut icon" href="favicon.ico" />
	<link rel="stylesheet" href="css/custom.css">

</head>
<body>
		
		
	<div class="header-a">
		<a href="signup.php">Register</a>
	</div>

	<div class="header-b">
		<a href="login.php">Sign In</a>
	</div>
	
	<br><br>

	<div class="up-container">
	<center><a href="index.php" ><h1>RLHAPT</h1></a></center>
	<center><h2>SECURITY <span class="training">TRAINING</span> PLATFORM</h2></center>	
	</div>

	<div class="mid-container">
	<center><p>Step into our world and start hacking. Defend your servers, and launch attacks on others, all using the exact same techniques that work in the real world.</p></center>	
	</div>	
	
	<div class="dwn-container">
	<center><a href="signup.php">Start Practice</a></center>
	</div>
	
	<div class="footer">
	<center><h5>&copy; 2017 - RLHAPT </h5></center>
		
	</div>
</body>
</html>