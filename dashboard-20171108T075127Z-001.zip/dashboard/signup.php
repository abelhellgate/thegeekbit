<?php

ob_start();
session_start();

include 'includes/connection.php';

if(isset($_GET['error'])){
	
	$error = $_GET['error'];
	
	if($error == 1){
		echo '<h1> Error! Password does not match!';
	}
}

if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['uname']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['cpassword'])){

	$fname = mysqli_real_escape_string($connection, $_POST['fname']);
	$lname = mysqli_real_escape_string($connection, $_POST['lname']);
	$username = mysqli_real_escape_string($connection, $_POST['uname']);
	$email = mysqli_real_escape_string($connection, $_POST['email']);
	$password = mysqli_real_escape_string($connection, $_POST['password']);
	$cpassword = mysqli_real_escape_string($connection, $_POST['cpassword']);
	
	if($password === $cpassword){
		
			$hashedPass = md5($password);
			$query = "INSERT INTO User (`first_name`, `last_name`, `username`, `email`, `user_role`, `password`) VALUES ('$fname', '$lname', '$username', '$email', 'User', '$hashedPass')";

			if(mysqli_query($connection, $query)){
			
					header("Location: login.php?msg=1");			
			}
				
	}
	else{
			header("Location: signup.php?error=1");
	}	
	
}

?>

<!DOCTYPE html>
<html>
  <head>
    <title>RLHAPT - Signup</title>
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- Bootstrap -->
    <link href="includes/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="includes/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
    <link href="includes/assets/styles.css" rel="stylesheet" media="screen">
     <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script src="includes/js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  </head>
  <body id="login">
    <div class="container">

		<center><img src="images/logo-splash.svg" alt=""></center><br />
      <form class="form-signin" action="signup.php" method="POST" >
      	<input name="fname" type="text" class="input-block-level" placeholder="First Name" required="">
			<input name="lname" type="text" class="input-block-level" placeholder="Last Name" required="">
			<input name="uname" type="text" class="input-block-level" placeholder="Username" required="">
			<input name="email" type="text" class="input-block-level" placeholder="Email address" required="">
			<input name="password" type="password" class="input-block-level" placeholder="Password" required="">
			<input name="cpassword" type="password" class="input-block-level" placeholder="Confirm Password" required="">
        	<center><button class="btn btn-large btn-primary" type="submit">Sign Up</button></center><br />
        	<div>Already a member? <a href="login.php">Click Here</a></div>
      </form>
      

    </div> <!-- /container -->
    <script src="includes/vendors/jquery-1.9.1.min.js"></script>
    <script src="includes/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>