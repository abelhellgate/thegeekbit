<?php

include 'session.php';
$pagetitle = 'Overview';
include 'header.php';

?>

	<div class="span9" id="content">
                    <div class="row-fluid">
                        
                        	<div class="navbar">
                            	<div class="navbar-inner">
	                                <ul class="breadcrumb">
	                                    <i class="icon-chevron-left hide-sidebar"><a href='#' title="Hide Sidebar" rel='tooltip'>&nbsp;</a></i>
	                                    <i class="icon-chevron-right show-sidebar" style="display:none;"><a href='#' title="Show Sidebar" rel='tooltip'>&nbsp;</a></i>
	                                    <li class="active">Dashboard</li>
	                                </ul>
                            	</div>
                        	</div>
                    	</div>
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                        		<div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Statistics</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span3">
                                    <div class="chart" data-percent='<?php echo get_server_cpu_usage(); ?>'><?php echo get_server_cpu_usage().'%'; ?></div>
                                    <div class="chart-bottom-heading"><span class="label label-info">CPU Usage</span>

                                    </div>
                                </div>
                                <div class="span3">
                                    <div class="chart" data-percent='<?php echo get_server_memory_usage(); ?>'><?php echo get_server_memory_usage().'%'; ?></div>
                                    <div class="chart-bottom-heading"><span class="label label-info">System Memory</span>

                                    </div>
                                </div>
                                <div class="span3">
                                    <div class="chart" data-percent='<?php echo get_user_percent($connection); ?>'><?php echo get_user_percent($connection).'%'; ?></div>
                                    <div class="chart-bottom-heading"><span class="label label-info">Users</span>

                                    </div>
                                </div>
                                <div class="span3">
                                    <div class="chart" data-percent='<?php echo rand(5, 65).'%'; ?>'><?php echo rand(5, 65).'%'; ?></div>
                                    <div class="chart-bottom-heading"><span class="label label-info">Network</span>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    <div class="row-fluid">
                        <div class="span6">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Users</div>
                                    <div class="pull-right"><span class="badge badge-info"><?php echo total_users($connection); ?></span>

                                    </div>
                                </div>
                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Username</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        
                                        	$i = 0;
                                        	
                                        	$query = "SELECT first_name, last_name, username FROM User WHERE user_role = 'User'";
														$result = mysqli_query($connection, $query);
                                        	
                                        	while($row = mysqli_fetch_array($result)){
                                        		$i++;
                                        ?>
                                             <tr>
                                                <td><?php echo $i; ?></td>
                                                <td><?php echo $row['first_name']; ?></td>
                                                <td><?php echo $row['last_name']; ?></td>
                                                <td><?php echo $row['username']; ?></td>
                                             </tr>
                                        <?php    
                                          }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                        <div class="span6">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Ranks</div>
                                    <div class="pull-right"><span class="badge badge-info"><?php echo total_users($connection); ?></span>

                                    </div>
                                </div>
                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Username</th>
                                                <th>Trophies</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        
                                        	$i = 0;
                                        	
                                        	$query = "SELECT user_id, rank FROM Score Order By rank";
														$result = mysqli_query($connection, $query);
                                        	
                                        	while($row = mysqli_fetch_array($result)){
                                        		$i++;
                                        ?>
                                            <tr>
                                                <td><?php echo $row['rank']; ?></td>
                                                
                                                <td>
                                                <?php 
                                                	$userid = $row['user_id'];
                                                	$query2 = "SELECT username FROM User WHERE user_id = $userid";
																	$result2 = mysqli_query($connection, $query2);
																	$username = mysqli_fetch_array($result2);
																	echo $username['username'];
                                                ?>
                                                </td>
                                                <td>0</td>
                                            </tr>
                                        <?php    
                                          }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                        <!-- Machines Table -->
                        
                        <div class="row-fluid">
                        <div class="span6">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Machines</div>
                                    <div class="pull-right"><span class="badge badge-info"><?php echo total_machines($cloud, $region); ?></span>

                                    </div>
                                </div>
                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
						                <tr>
						                  <th>#</th>
						                  <th>Machine Name</th>
						                  <th>Private IP</th>
						                  <th>Floating IP</th>
						                  <th>Status</th>
						                </tr>
						              </thead>
						              <tbody>
						             <?php
						             
						             	$compute = $cloud->computeV2(['region' => $region]);
											$servers = $compute->listServers(true);
											$i = 1;
											
											foreach ($servers as $server) {

												$extractData = get_object_vars($server);
												$extractData = get_object_vars($server);
												$machine_name = $extractData['name'];
	
												foreach($extractData['addresses'] as $a){
	
													$private_ip = $a[0]['addr'];
													$floating_ip = $a[1]['addr'];
													
											?>
											
											<tr>
												<td><?php echo $i; ?></td>
						                  <td><?php echo $machine_name; ?></td>
						                  <td><?php echo $private_ip; ?></td>
						                  <td><?php echo $floating_ip; ?></td>
						                  <td><?php echo $extractData['status']; ?></td>
						                </tr>
						                
											<?php
												}
											$i++;
											}
                              ?>
						              </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                        
                        <!-- Machines Table End -->
                        <!-- Networks Table Start -->
								<div class="span6">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Networks</div>
                                    <div class="pull-right"><span class="badge badge-info"><?php echo total_networks($cloud); ?></span>

                                    </div>
                                </div>
                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Network Name</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $networking = $cloud->networkingV2();
													 $networks = $networking->listNetworks();
													 $i = 0;
													
													 foreach($networks as $network){
													 		
															$extractData = get_object_vars($network);
															
															if($extractData['name'] != 'public'){
																$i++;
													 ?>		
															<tr>
                                                <td><?php echo $i; ?></td>
                                                <td><?php echo $extractData['name']; ?></td>
                                                <td><?php echo $extractData['status']; ?></td>
                                            </tr>
													<?php
															}		
													 }
													 ?>
                                            
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /block -->
                        </div>                        
                        
                        <!-- Networks Table End -->
                        
                    </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>