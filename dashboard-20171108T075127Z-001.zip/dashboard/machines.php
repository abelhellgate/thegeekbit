<?php

include 'session.php';
$pagetitle = 'Machines';

if(isset($_GET['server']) && isset($_GET['currentstatus']) && isset($_GET['action'])){

			$machine_id = $_GET['server'];
			$currentstatus = $_GET['currentstatus'];
			$action = $_GET['action'];
			
			switch ($action) {
    			case 'start':
    				if($currentstatus == 'ACTIVE')
    					header('Location: machines.php?action=start&err=1');
    				else{
						startServer($cloud, $region, $machine_id);
						sleep(3);
						header('Location: machines.php?action=start&msg=success');
					}
        			break;
        		case 'stop':
        			if($currentstatus == 'SHUTOFF')
    					header('Location: machines.php?action=stop&err=2');
    				else{
						stopServer($cloud, $region, $machine_id);
						sleep(3);
						header('Location: machines.php?action=stop&msg=success');
					}
        			break;
    			case 'reboot':
    				rebootServer($cloud, $region, $machine_id);
    				sleep(3);
    				header('Location: machines.php?action=reboot&msg=success');
        			break;        			
			}
	
}

include 'header.php';

?>
				<div class="span9" id="content">
                
                 <!--Success Message Code -->
                <?php	
                
                	if(isset($_GET['action']) && isset($_GET['msg'])){
                	
                			$action = $_GET['action'];
                			$msg = $_GET['msg'];
                			if($msg == 'success'){
                			
                	
                ?>
                	<div class="row-fluid">
                            <div class="block-content collapse in">
                            	<div class="span12">
                           	<div class="alert alert-success alert-block">
												<a class="close" data-dismiss="alert" href="#">&times;</a>
												<h4 class="alert-heading">Success!</h4>
												<?php
													switch($action){
														case 'start';
															echo 'The Server has successfully been Started.';
															break;
														case 'stop';
															echo 'The Server has successfully been Stopped.';
															break;
														case 'reboot';
															echo 'The Server has successfully been Rebooted.';
															break;
													}
												?>
										</div>
										</div>
                            </div>
                    </div>
                <?php
                
								}
                	}
                                
                ?>
                <!--Success Message Code Ends -->
                    
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Machines</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table class="table">
						              <thead>
						                <tr>
						                  <th>#</th>
						                  <th>Machine Name</th>
						                  <th>Private IP</th>
						                  <th>Floating IP</th>
						                  <th>Status</th>
						                  <th>Action</th>
						                </tr>
						              </thead>
						              <tbody>
						             <?php
						             
						             	$compute = $cloud->computeV2(['region' => $region]);
											$servers = $compute->listServers(true);
											$i = 1;
											
											foreach ($servers as $server) {

												$extractData = get_object_vars($server);
												$machine_name = $extractData['name'];
												$machine_id = $extractData['id'];
												$currentstatus = $extractData['status'];
	
												foreach($extractData['addresses'] as $a){
	
													$private_ip = $a[0]['addr'];
													$floating_ip = $a[1]['addr'];
													
											?>
											
											<tr>
												<td><?php echo $i; ?></td>
						                  <td><?php echo $machine_name; ?></td>
						                  <td><?php echo $private_ip; ?></td>
						                  <td><?php echo $floating_ip; ?></td>
						                  <td><?php echo $currentstatus; ?></td>
						                  <td><a href='<?php echo "machines.php?server=$machine_id&currentstatus=$currentstatus&action=start"; ?>'><i class="icon-play"></i></a><a href='<?php echo "machines.php?server=$machine_id&currentstatus=$currentstatus&action=stop"; ?>'><i class="icon-stop"></i></a><a href='<?php echo "machines.php?$machine_id&currentstatus=$currentstatus&action=reboot"; ?>'><i class="icon-refresh"></i></a></td>
						                </tr>
						                
											<?php
												}
											$i++;
											}
                              ?>
						              </tbody>
						            </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    
                </div>
            </div>
            <?php include 'footer.php'; ?>