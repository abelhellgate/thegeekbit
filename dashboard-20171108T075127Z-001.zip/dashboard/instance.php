<?php

include 'session.php';
$pagetitle = 'Instances';
	
if(isset($_POST['instancename']) && isset($_POST['image']) && isset($_POST['network'])){

		$instanceName = $_POST['instancename'];
		$imageid = $_POST['image'];
		$networkid = $_POST['network'];
		$instanceid = 0;
			
		$instanceid = createInstance($cloud, $instanceName, $region, $imageid, $networkid);
		
		if($instanceid != 0){
			
			header('Location: instance.php?status=success');
		}
		
}

include 'header.php';

?>
                <div class="span9" id="content">
                
                <!--Success Message Code -->
                <?php	
                
                	if(isset($_GET['status'])){
                	
                			$status = $_GET['status'];
                			if($status == 'success'){
                			
                	
                ?>
                	<div class="row-fluid">
                        <!-- block -->
                            <div class="block-content collapse in">
                                <div class="span12">
									<div class="alert alert-success alert-block">
										<a class="close" data-dismiss="alert" href="#">&times;</a>
										<h4 class="alert-heading">Success!</h4>
										The Instance has successfully been Launched.
									</div>

								</div>
                            </div>
                        <!-- /block -->
                    </div>
                <?php
                
								}
                	}
                                
                ?>
                <!--Success Message Code Ends -->
                
                    <!-- Form Validation -->
                   <div class="row-fluid">
                         <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Launch Instance</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
					<!-- BEGIN FORM-->
					<form action="instance.php" id="instance-form" class="form-horizontal" method="POST">
						<fieldset>
							
  							<div class="control-group">
  								<label class="control-label">Instance Name<span class="required">*</span></label>
  								<div class="controls">
  									<input name="instancename" type="text" class="span6 m-wrap"/>
  								</div>
  							</div>
  							
  							<div class="control-group">
                         <label class="control-label" for="select01">Choose Image</label>
                         <div class="controls">
                             <select id="select01" class="chzn-select" name="image">
                             <?php
                             		$images = $cloud->imagesV2()->listImages();
											foreach($images as $image){
													$extractData = get_object_vars($image);
													
                             ?>
                              	<option value=<?php echo $extractData['id']; ?>><?php echo $extractData['name']; ?></option>
                             <?php
                                 }
                             ?>
                             </select>
                         </div>
                     </div>
                     
                     <div class="control-group">
                         <label class="control-label" for="select02">Choose Network</label>
                         <div class="controls">
                             <select id="select02" class="chzn-select" name="network">
                             <?php
                             		$networking = $cloud->networkingV2();
											$networks = $networking->listNetworks();
											
											foreach($networks as $network){
													$extractData = get_object_vars($network);
													if($extractData['name'] != 'public' && $extractData['name'] != 'private' ){					
                             ?>
                              	<option value=<?php echo $extractData['id']; ?>><?php echo $extractData['name']; ?></option>
                             <?php
                             				}
                                 }
                             ?>
                             </select>
                         </div>
                     </div>
  							
  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Launch Instance</button>
  							</div>
						</fieldset>
					</form>
					<!-- END FORM-->
				</div>
			    </div>
			</div>
                     	<!-- /block -->
		    </div>
                    
                </div>
            </div>
            <?php include 'footer.php'; ?>