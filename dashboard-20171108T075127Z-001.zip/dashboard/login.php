<?php

ob_start();
session_start();

include 'includes/connection.php';


if(isset($_GET['msg'])){
	
	$msg = $_GET['msg'];
	
	if($msg == 1){
		echo '<center><h3 style="color: White;"> Signup Successful! Please Login. </h3></center>';
	}
}

if(isset($_GET['err'])){
	
	$err = $_GET['err'];
	
	if($err == 1){
		echo '<center><h3 style="color: White;"> Please Login First! </h3></center>';
	}
}

if(isset($_POST['email']) && isset($_POST['password'])){

	$email = mysqli_real_escape_string($connection, $_POST['email']);
	$password = mysqli_real_escape_string($connection, $_POST['password']);
	$hashedPass = md5($password);
	
	$query = "SELECT user_id FROM `User` WHERE `email` = '$email' AND `password` = '$hashedPass'";

	$result = mysqli_query($connection, $query);
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
	$count = mysqli_num_rows($result);
	
	if($count > 0){
			
			$_SESSION['loggedin'] = 'true';
			$_SESSION['user_id'] = $row['user_id'];

			header("Location: dashboard.php");
					
	}else {
			
			echo '<h3> Username/Password Incorrect! </h3>';	
	}
}

?>

<!DOCTYPE html>
<html>
  <head>
    <title>RLHAPT - Login</title>
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- Bootstrap -->
    <link href="includes/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="includes/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
    <link href="includes/assets/styles.css" rel="stylesheet" media="screen">
     <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script src="includes/js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  </head>
  <body id="login">
    <div class="container">

		<center><img src="images/logo-splash.svg" alt=""></center><br />
      <form class="form-signin" action="login.php" method="POST" >
        <input name="email" type="text" class="input-block-level" placeholder="Email address">
        <input name="password" type="password" class="input-block-level" placeholder="Password">
        <label name="check" class="checkbox">
          <input type="checkbox" value="remember-me"> Remember me
        </label>
        <center><button class="btn btn-large btn-primary" type="submit" >Sign in</button></center>
      </form>

    </div> <!-- /container -->
    <script src="includes/vendors/jquery-1.9.1.min.js"></script>
    <script src="includes/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>